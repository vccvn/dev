
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{$siteinfo->favicon?$siteinfo->favicon:theme_asset('images/favicon.png')}}">

    <!-- Site Stylesheet -->
    <link rel="stylesheet" href="{{theme_asset('css/style.min.css?v=1.2')}}">