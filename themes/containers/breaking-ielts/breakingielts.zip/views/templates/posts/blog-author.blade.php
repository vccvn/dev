

                        <div class="blog-author">
                            <div class="thumbnail">
                                <img src="assets/images/blog/author-01.jpg" alt="Author Images">
                            </div>
                            <div class="author-content">
                                <h5 class="title">Edward Norton</h5>
                                <p>Enim ad minim veniam quis nostrud exercitation lamco laboris nisi ex commodo consequat aute irure.</p>
                                <ul class="social-share icon-transparent">
                                    <li>
                                        <a href="#"><i class="icon-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="icon-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="icon-instagram"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
