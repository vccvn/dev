

    <!-- JS
	============================================ -->
    <!-- Modernizer JS -->
    <script src="{{theme_asset('js/vendor/modernizr.min.js')}}"></script>
    <!-- Jquery Js -->
    <script src="{{theme_asset('js/vendor/jquery.js')}}"></script>
    <script src="{{theme_asset('js/vendor/bootstrap.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/sal.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/backtotop.js')}}"></script>
    <script src="{{theme_asset('js/vendor/magnifypopup.js')}}"></script>
    <script src="{{theme_asset('js/vendor/slick.js')}}"></script>
    <script src="{{theme_asset('js/vendor/jquery.countdown.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/jquery-appear.js')}}"></script>
    <script src="{{theme_asset('js/vendor/odometer.js')}}"></script>
    <script src="{{theme_asset('js/vendor/isotop.js')}}"></script>
    <script src="{{theme_asset('js/vendor/imageloaded.js')}}"></script>
    <script src="{{theme_asset('js/vendor/lightbox.js')}}"></script>
    <script src="{{theme_asset('js/vendor/wow.js')}}"></script>
    <script src="{{theme_asset('js/vendor/paralax.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/paralax-scroll.js')}}"></script>
    <script src="{{theme_asset('js/vendor/jquery-ui.js')}}"></script>
    <script src="{{theme_asset('js/vendor/swiper-bundle.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/svg-inject.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/vivus.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/tipped.min.js')}}"></script>
    <script src="{{theme_asset('js/vendor/viewport.jquery.js')}}"></script>

    <!-- Site Scripts -->
    <script src="{{theme_asset('js/app.js')}}"></script>