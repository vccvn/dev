
                        <div class="course-sidebar-2">
                            {!! $html->sidebar_courses->components !!}
                        </div>