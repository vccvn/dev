
                        <div class="course-sidebar-2">
                            {!! $html->sidebar_posts->components !!}
                        </div>

                        