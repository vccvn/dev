


                        <div class="edu-blog-sidebar">
                            {!! $html->sidebar_pages->components !!}
                        </div>