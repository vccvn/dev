
                        <div class="course-sidebar-2">
                            {!! $html->sidebar_pages->components !!}
                        </div>

                        