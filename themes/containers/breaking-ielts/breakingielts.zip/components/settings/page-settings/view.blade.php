{!!
    isset($children)?$children:''
!!}