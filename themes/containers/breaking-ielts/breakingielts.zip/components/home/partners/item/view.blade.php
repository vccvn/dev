
<div class="brand-grid">
    <a href="{{$data->link}}">
        <img src="{{theme_asset('images/brand/brand-01.png')}}" alt="{{$data->title}}">
    </a>
</div>