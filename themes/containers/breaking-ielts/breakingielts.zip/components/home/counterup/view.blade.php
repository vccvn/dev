
<div class="edu-counterup counterup-style-2">
    <h2 class="counter-item count-number {{$data->style}}-color">
        <span class="odometer" data-odometer-final="{{$data->number(0)}}">.</span><span>{{$data->unit}}</span>
    </h2>
    <h6 class="title">{{$data->title}}</h6>
</div>